Release Notes
=============

* [`0.9.0`](https://github.com/basho/erlang_protobuffs/issues?q=milestone%3Aerlang_protobuffs-0.9.0)
 * [Use single-quotes to quote reserved words instead of prefixing with `pb_`](https://github.com/basho/erlang_protobuffs/pull/102)
* [`0.8.4`](https://github.com/basho/erlang_protobuffs/issues?q=milestone%3Aerlang_protobuffs-0.8.4)
 * Ensure `rebar.config` uses `https` dep URLs. `git://` may be blocked.
* [`0.8.3`](https://github.com/basho/erlang_protobuffs/issues?q=milestone%3Aerlang_protobuffs-0.8.3)
 * OTP 18 support.
