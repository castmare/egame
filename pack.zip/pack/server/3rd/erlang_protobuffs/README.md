# NOTICE

This project, `erlang_protobuffs`, is no longer actively maintained. Please use [`gpb`](https://github.com/tomas-abrahamsson/gpb) instead. `gpb` has `erlang_protobuffs` compatibility and is actively maintained by @tomas-abrahamsson

[`README_ORIG.md`](https://github.com/basho/erlang_protobuffs/blob/master/README_ORIG.md) contains this project's original `README.md` content.
