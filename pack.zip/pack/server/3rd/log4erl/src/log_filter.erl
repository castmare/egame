%% Author: David Dossot <david@dossot.net>
%% Created: Oct 25, 2009
-module(log_filter).

-export([cutoff_level/0]).

cutoff_level() -> all.
