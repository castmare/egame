declare module skins{
	class ButtonSkin extends eui.Skin{
	}
}
declare module skins{
	class CheckBoxSkin extends eui.Skin{
	}
}
declare module skins{
	class HScrollBarSkin extends eui.Skin{
	}
}
declare module skins{
	class HSliderSkin extends eui.Skin{
	}
}
declare module skins{
	class ItemRendererSkin extends eui.Skin{
	}
}
declare module skins{
	class PanelSkin extends eui.Skin{
	}
}
declare module skins{
	class ProgressBarSkin extends eui.Skin{
	}
}
declare module skins{
	class RadioButtonSkin extends eui.Skin{
	}
}
declare module skins{
	class RockerSkin extends eui.Skin{
	}
}
declare module skins{
	class ScrollerSkin extends eui.Skin{
	}
}
declare module skins{
	class TextInputSkin extends eui.Skin{
	}
}
declare module skins{
	class ToggleSwitchSkin extends eui.Skin{
	}
}
declare module skins{
	class VScrollBarSkin extends eui.Skin{
	}
}
declare module skins{
	class VSliderSkin extends eui.Skin{
	}
}
declare class CreateRoleSkin extends eui.Skin{
}
declare class EditButtonSkin extends eui.Skin{
}
declare class ElementSkin extends eui.Skin{
}
declare class ElfCardSkin extends eui.Skin{
}
declare class ElfDetailSkin extends eui.Skin{
}
declare class ElfInfoSkin extends eui.Skin{
}
declare class ElfLevelSkin extends eui.Skin{
}
declare class ElfNameSkin extends eui.Skin{
}
declare class ElfSelectSkin extends eui.Skin{
}
declare class MainSceneSkin extends eui.Skin{
}
declare class SkillDescSkin extends eui.Skin{
}
declare class SkillDetailSkin extends eui.Skin{
}
declare class SkillIconSkin extends eui.Skin{
}
declare class SkillInfoSkin extends eui.Skin{
}
declare class SkillLookupSkin extends eui.Skin{
}
