class Rocker extends eui.Component {
    constructor() {
        super();
        this.skinName = "skins.RockerSkin";
    }
}